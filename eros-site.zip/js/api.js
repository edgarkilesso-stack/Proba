// ===== СЛОЙ РАБОТЫ С API =====
// Эти функции повторяют flow документации ErosAI:
// catalog -> files -> estimate -> generations -> tasks -> result
// Сейчас они возвращают демо-данные. Когда появится сервер,
// заменим тело функций на реальные fetch-запросы к CONFIG.API_BASE.

async function apiGetCatalog() {
  // Реальный вариант: GET /catalog
  // Сейчас — демо-каталог
  return [
    { id: "tpl_1", kind: "VIDEO_TEMPLATE", title: "Шаблон видео №1", desc: "Описание шаблона", price: "129",
      thumb: "" },
    { id: "tpl_2", kind: "VIDEO_TEMPLATE", title: "Шаблон видео №2", desc: "Описание шаблона", price: "149",
      thumb: "" },
    { id: "tpl_3", kind: "PHOTO_TEMPLATE", title: "Шаблон фото №1", desc: "Описание шаблона", price: "79",
      thumb: "" },
    { id: "tpl_4", kind: "CUSTOM", title: "Свой сценарий", desc: "Промпт + загруженное фото", price: "от 99",
      thumb: "" },
  ];
}

async function apiUploadFile(file) {
  // Реальный вариант: POST /files (multipart)
  // Сейчас — имитация загрузки
  await new Promise(r => setTimeout(r, 800));
  return { file_id: "demo_" + Math.random().toString(36).slice(2, 10) };
}

async function apiEstimate(kind, itemId, fileIds, params) {
  // Реальный вариант: POST /generations/estimate
  return { price: 129, currency: "RUB" };
}

async function apiStartGeneration(kind, itemId, fileIds, params) {
  // Реальный вариант: POST /generations
  await new Promise(r => setTimeout(r, 600));
  return { task_id: "demo_task_" + Math.random().toString(36).slice(2, 10) };
}

async function apiGetTaskStatus(taskId) {
  // Реальный вариант: GET /tasks/{taskId} — опрашиваем, пока не "done"
  return { status: "processing", progress: 45 };
}

async function apiGetTaskResult(taskId) {
  // Реальный вариант: GET /tasks/{taskId}/result
  return { url: "" };
}
